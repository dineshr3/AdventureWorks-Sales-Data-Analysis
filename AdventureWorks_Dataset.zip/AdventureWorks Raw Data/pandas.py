import pandas as pd

df = pd.read_csv("AdventureWorks Customer Lookup.csv")

print(df)